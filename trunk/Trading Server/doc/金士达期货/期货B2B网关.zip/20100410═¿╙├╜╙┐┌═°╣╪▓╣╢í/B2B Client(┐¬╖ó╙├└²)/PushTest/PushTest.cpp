// PushTest.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
#include <winsock2.h>

#include <windows.h>
#include <stdio.h>
#include <process.h>
#include <conio.h>
#include "TaskThread.h"
#define SERVER_PORT 17992
#define MSG_MAXLEN 1024
#define CMD_CONNECT	1		// ����

// push header
typedef struct {
	unsigned short usType;
	unsigned short usLength;
} ST_PUSHHEAD;


// Handle push link receive 
void handlePushRecv(SOCKET sock)
{
	ST_PUSHHEAD stPushHead;		// push header
	int nHeaderLen = sizeof(ST_PUSHHEAD);	// push header length
	int nDataLen = 0;			// recv data length
	int s_nReceived = 0;		// static para
	int nType;					// command type
	int nRead = 0;				// counter of recv char
	char szRecvBuffer[MSG_MAXLEN] = "";	// recv buffer
	
	// begin recv  ||  just recv a part of header
	if (s_nReceived < nHeaderLen)
	{
		nDataLen = 0;
		
		nRead = ::recv (sock, (char *) &stPushHead + s_nReceived, nHeaderLen - s_nReceived, 0);
		
		if (nRead <= 0)
		{
			// sock error occurs, must close
			if (GetLastError() != WSAEWOULDBLOCK)
			{
				s_nReceived = 0;
				return;
			}
		}
		
		s_nReceived += nRead;
		
		if (s_nReceived < nHeaderLen)
			return;
		
		nDataLen = ntohs(stPushHead.usLength);
		nType = ntohs(stPushHead.usType);
	}
	
	if (nDataLen > MSG_MAXLEN || nDataLen < 0)
	{
		s_nReceived = 0;
		return;
	}
	
	// just recv a part of whole pack
	if (s_nReceived < nHeaderLen + nDataLen)
	{
		nRead = ::recv (sock, szRecvBuffer + s_nReceived - nHeaderLen, 
			nDataLen + nHeaderLen - s_nReceived, 0);
		
		if (nRead <= 0)
		{
			if (GetLastError() != WSAEWOULDBLOCK)
			{
				s_nReceived = 0;
				return;
			}
			
		}
		
		s_nReceived += nRead;
		
	}
	
	// recv whole pack
	if (s_nReceived == nHeaderLen + nDataLen)
	{
		// print message
		printf ("receive from server: [%d]%s\n", nType, szRecvBuffer);

		// reset param
		s_nReceived = 0;
		nDataLen = 0;
		memset(szRecvBuffer, 0, sizeof(MSG_MAXLEN));
	}
}

int main(int argc, char* argv[])
{
	if (argc != 2)
	{
		printf("Usage: %s <IP Addresss>\n", argv[0]);
	}

	// initialize
	SOCKET hSockContral;
	sockaddr_in tagSockAddrServer;
	int nReturn;
	char cServerMsg [MSG_MAXLEN];
	char cClientMsg [MSG_MAXLEN];
	memset (cServerMsg, 0, sizeof (cServerMsg) );
	memset (cClientMsg, 0, sizeof (cClientMsg) );

	// WSAStartup	
	WSADATA wsaData;
	if (WSAStartup (MAKEWORD (2,2), &wsaData) )
	{
		printf ("WSAStartup() failed, Error Number: %d" ,GetLastError() );
		getchar ();
		exit (1);
	}

	// Create the socket
	hSockContral = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (hSockContral == INVALID_SOCKET)
	{
		perror ("socket");
		getchar ();
		exit (1);
	}

	// Set values to server sockaddr
	memset (&tagSockAddrServer, 0, sizeof (tagSockAddrServer) );
	tagSockAddrServer.sin_family = AF_INET;
	tagSockAddrServer.sin_port = htons(SERVER_PORT);
	tagSockAddrServer.sin_addr.S_un.S_addr = inet_addr (argv[1]);
	//tagSockAddrServer.sin_addr.S_un.S_addr = inet_addr ("10.253.44.94");
	
	// connect to server
	nReturn = connect (hSockContral, (sockaddr*) &tagSockAddrServer, sizeof (tagSockAddrServer) );
	if (nReturn == -1)
	{
		perror ("connect failed, sys error message:");
		getchar ();
		exit (1);
	}
	printf ("client connected to server %s.\n", inet_ntoa (tagSockAddrServer.sin_addr) );
	

	// send connect command to server
	char szSend[MSG_MAXLEN];
	memset(szSend, 0, sizeof(szSend));
	ST_PUSHHEAD* pstPushHead = (ST_PUSHHEAD *)szSend;
	pstPushHead->usType = htons(CMD_CONNECT);
	nReturn = ::send(hSockContral, szSend, sizeof(szSend), 0);
	if (nReturn == -1)
	{
		perror ("send");
		getchar ();
		exit (1);
	}
	printf ("Sent to server: %s, total %d chars\n", cClientMsg, nReturn);

	// Receive from server
	while(1)
	{
		handlePushRecv(hSockContral);
	}
	
	// close socket
	nReturn = closesocket (hSockContral);
	printf ("closesocket:%d.\n", hSockContral);

	// WSACleanup
	if (WSACleanup ())
	{
		perror("WSACleanup");
		exit (1);
	}

	getchar ();

	return 0;
}

