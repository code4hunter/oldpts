// TaskThread.h: interface for the CTaskThread class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TASKTHREAD_H__B21EF597_AC62_4DFD_A518_9906AF86B168__INCLUDED_)
#define AFX_TASKTHREAD_H__B21EF597_AC62_4DFD_A518_9906AF86B168__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTaskThread  
{
public:
	CTaskThread();
	virtual ~CTaskThread();

public:
	virtual bool Create ( void );
	virtual bool Destroy ( void );
	virtual void StartService ( void );
	virtual void EndService ( void );

public:
	bool IsInitFinished ( void ) { return m_bInitFinished; }
	
private:
	static unsigned __stdcall ThreadFunc ( void* arg );

protected:
	virtual bool ThreadInitialize ();
	virtual bool ThreadUninitialize ();

private:
	virtual void DoWork ();

protected:
	bool m_bInitFinished;
	bool m_bExit;
	bool m_bSuspend;
	HANDLE m_hThread;
};

#endif // !defined(AFX_TASKTHREAD_H__B21EF597_AC62_4DFD_A518_9906AF86B168__INCLUDED_)
