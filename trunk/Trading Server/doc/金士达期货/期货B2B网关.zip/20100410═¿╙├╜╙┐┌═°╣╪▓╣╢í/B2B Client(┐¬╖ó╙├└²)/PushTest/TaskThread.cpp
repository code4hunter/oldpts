// TaskThread.cpp: implementation of the CTaskThread class.
//
//////////////////////////////////////////////////////////////////////
/*
#include "TaskThread.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTaskThread::CTaskThread(void)
:m_hThread ( NULL )
,m_bExit ( false )
,m_bSuspend ( false )
,m_bInitFinished ( false )
{
}

CTaskThread::~CTaskThread( void )
{
	if ( m_hThread != NULL )
	{
		::CloseHandle( m_hThread );
	}
}

bool CTaskThread::Create ( void )
{
	m_bExit = false;
	m_bSuspend = false;
	unsigned id;
	m_hThread = ( HANDLE )_beginthreadex ( NULL, 0, ThreadFunc, (void*)this, 0, &id );
	return m_hThread != NULL;
}

bool CTaskThread::Destroy ( void )
{
	m_bExit = true;
	if ( m_hThread != NULL )
	{
		StartService ();
		::CloseHandle ( m_hThread );
		m_hThread = NULL;
	}
	return true;
}

void CTaskThread::StartService()
{
	if ( ( m_hThread != NULL ) && m_bSuspend )
	{
		m_bSuspend = false;
		::ResumeThread ( m_hThread );
	}
}

void CTaskThread::EndService()
{
	if ( ( m_hThread != NULL ) && !m_bSuspend )
	{
		m_bSuspend = true;
		::SuspendThread ( m_hThread );
	}
}

unsigned __stdcall CTaskThread::ThreadFunc(void* arg)
{
/*
		CTaskThread* pThis = (CTaskThread*)arg;
		pThis->m_bInitFinished = false;
		if (pThis->ThreadInitialize())
		{
		}
		else
		{
			pThis->ThreadUninitialize();		
			return (unsigned)-1;
		}
		pThis->m_bInitFinished = true;
		
		pThis->DoWork();
		
		pThis->ThreadUninitialize();*//*
	SOCKET hSockContral;
	sockaddr_in tagSockAddrServer;
	int nReturn;
	char cServerMsg [MSG_MAXLEN];
	char cClientMsg [MSG_MAXLEN];
	memset (cServerMsg, 0, sizeof (cServerMsg) );
	memset (cClientMsg, 0, sizeof (cClientMsg) );
	WSADATA wsaData;
	if (WSAStartup (MAKEWORD (2,2), &wsaData) )
	{
		printf ("WSAStartup() failed, Error Number: %d" ,GetLastError() );
		getchar ();
		exit (1);
	}
	
	// Create the socket
	hSockContral = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (hSockContral == INVALID_SOCKET)
	{
		perror ("socket");
		getchar ();
		exit (1);
	}
	
	// Set values to server sockaddr
	memset (&tagSockAddrServer, 0, sizeof (tagSockAddrServer) );
	tagSockAddrServer.sin_family = AF_INET;
	tagSockAddrServer.sin_port = htons(17992);
	//tagSockAddrServer.sin_addr.S_un.S_addr = inet_addr (argv[1]);
	tagSockAddrServer.sin_addr.S_un.S_addr = inet_addr ("10.253.44.94");
	// connect to server
	nReturn = connect (hSockContral, (sockaddr*) &tagSockAddrServer, sizeof (tagSockAddrServer) );
	if (nReturn == -1)
	{
		perror ("connect failed, sys error message:");
		getchar ();
		exit (1);
	}
	printf ("client connected to server %s.\n", inet_ntoa (tagSockAddrServer.sin_addr) );
	
	
	// send connect command to server
	char szSend[MSG_MAXLEN];
	memset(szSend, 0, sizeof(szSend));
	ST_PUSHHEAD* pstPushHead = (ST_PUSHHEAD *)szSend;
	pstPushHead->usType = htons(CMD_CONNECT);
	nReturn = ::send(hSockContral, szSend, sizeof(szSend), 0);
	if (nReturn == -1)
	{
		perror ("send");
		getchar ();
		exit (1);
	}
	printf ("Sent to server: %s, total %d chars\n", cClientMsg, nReturn);
	
	// Receive from server
	while(1)
	{
		
	}
	
	// close socket
	nReturn = closesocket (hSockContral);
	printf ("closesocket:%d.\n", hSockContral);
	
	// WSACleanup
	if (WSACleanup ())
	{
		perror("WSACleanup");
		exit (1);
	}
	
	getchar ();
	
	return 0;
	
	return 0;
}

void CTaskThread::DoWork()
{
	//	do nothing, derived class must override this function
}

bool CTaskThread::ThreadInitialize()
{
	return true;
}

bool CTaskThread::ThreadUninitialize()
{
	return true;
}
*/