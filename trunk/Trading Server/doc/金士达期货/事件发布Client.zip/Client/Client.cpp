// Client.cpp : Defines the entry point for the console application.
// 2006.11.12 by wangliang
//

#include <stdio.h>
#include <winsock2.h>

#define MSG_MAXLEN 600

void handle_message (SOCKET hSockContral, char * szClientMsg, int nLen)
{
	int nReturn;
	char szServerMsg [MSG_MAXLEN];
	memset (szServerMsg, 0, sizeof (szServerMsg) );

	// send message to server
	nReturn = send (hSockContral, szClientMsg, nLen, 0);
	if (nReturn == -1)
	{
		perror ("send");
		exit (1);
	}
	printf ("%s\n", szClientMsg);
	
	
	// Receive from server
	nReturn = recv (hSockContral, szServerMsg, sizeof (szServerMsg), 0);
	if (nReturn == -1)
	{
		perror ("recv");
		exit (1);
	}
	printf ("%s\n", szServerMsg);
}


int main(int argc, char* argv[])
{
	if (argc != 3)
	{
		printf("Usage: %s <IP Addresss> <PORT>\n", argv[0]);
		exit (1);
	}

	// initialize
	SOCKET hSockContral;
	sockaddr_in tagSockAddrServer;
	int nReturn;

	// WSAStartup	
	WSADATA wsaData;
	if (WSAStartup (MAKEWORD (2,2), &wsaData) )
	{
		printf ("WSAStartup() failed, Error Number: %d" ,GetLastError() );
		exit (1);
	}

	// Create the socket
	hSockContral = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (hSockContral == INVALID_SOCKET)
	{
		perror ("socket");
		exit (1);
	}

	// Set values to server sockaddr
	memset (&tagSockAddrServer, 0, sizeof (tagSockAddrServer) );
	tagSockAddrServer.sin_family = AF_INET;
	tagSockAddrServer.sin_port = htons(atoi(argv[2]) );
	tagSockAddrServer.sin_addr.S_un.S_addr = inet_addr (argv[1]);

	// connect to server
	nReturn = connect (hSockContral, (sockaddr*) &tagSockAddrServer, sizeof (tagSockAddrServer) );
	if (nReturn == -1)
	{
		perror ("connect failed, sys error message:");
		exit (1);
	}

	char szClientMsg [MSG_MAXLEN];
	memset (szClientMsg, 0, sizeof (szClientMsg) );


	/*******************************************************
	 *	request-response examples
	 *******************************************************/


	// login
	sprintf(szClientMsg, "%s", "R|||6011|||200888|1|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// order
	sprintf(szClientMsg, "%s", "R|||6021|||200888|1|A|al0707|0|0|0|1|20750|10200888");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	
	// query order status
	sprintf(szClientMsg, "%s", "R|||6020|||200888|1|1");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	
	// order-cancel
	sprintf(szClientMsg, "%s", "R|||6022|||200888|1||||||||12|||SFE|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// qurey fund
	sprintf(szClientMsg, "%s", "R|||6012|||200888|1||");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// qurey mapno (multi-records)
	sprintf(szClientMsg, "%s", "R|||6040|||200888|1|||");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// qurey quotation
	sprintf(szClientMsg, "%s", "R|||6017|||200888|1|A|cu0707|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// qurey position(multi-records)
	sprintf(szClientMsg, "%s", "R|||6014|||200888|1||||");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// qurey order(multi-records)
	sprintf(szClientMsg, "%s", "R|||6019|||200888|1||||||");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// qurey deal(multi-records)
	sprintf(szClientMsg, "%s", "R|||6013|||200888|1|||||");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// qurey contract(multi-records)
	sprintf(szClientMsg, "%s", "R|||6018|||200888|1|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// qurey cust info(multi-records)
	sprintf(szClientMsg, "%s", "R|||6045|||200888|1|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// qurey futures-bank account (multi-records)
	sprintf(szClientMsg, "%s", "R|||6042|||200888|1|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// futures-bank trans
	sprintf(szClientMsg, "%s", "R|||6041|||200888|1|1|18800|01|000001|4155990128726129|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// qurey futures-bank trans(multi-records)
	sprintf(szClientMsg, "%s", "R|||6043|||200888|1||||");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	sprintf(szClientMsg, "%s", "R|||0|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// modify trade password
	sprintf(szClientMsg, "%s", "R|||6023|||200888|1|1|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );
	
	// modify fund password
	sprintf(szClientMsg, "%s", "R|||6024|||200888|1|1|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// logout
	sprintf(szClientMsg, "%s", "R|||6061|||200888|1|");
	handle_message(hSockContral, szClientMsg, strlen(szClientMsg) );

	// close socket
	nReturn = closesocket (hSockContral);

	// WSACleanup
	if (WSACleanup ())
	{
		perror("WSACleanup");
		exit (1);
	}

	getchar();
	
	return 0;
}
